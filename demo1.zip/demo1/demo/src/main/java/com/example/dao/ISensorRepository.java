package com.example.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.entity.Sensor;

public interface ISensorRepository extends CrudRepository<Sensor, Long>{

}
