package com.example.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Sensor")
public class Sensor {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long signalId;
    private String speedOfVehical;
    private String typeOfVehical;
    
    public Sensor(){
    	
    }

	public Sensor(String speedOfVehical, String typeOfVehical) {
		this.speedOfVehical = speedOfVehical;
		this.typeOfVehical = typeOfVehical;
	}

	public long getSignalId() {
		return signalId;
	}

	public void setSignalId(long signalId) {
		this.signalId = signalId;
	}

	public String getSpeedOfVehical() {
		return speedOfVehical;
	}

	public void setSpeedOfVehical(String speedOfVehical) {
		this.speedOfVehical = speedOfVehical;
	}

	public String getTypeOfVehical() {
		return typeOfVehical;
	}

	public void setTypeOfVehical(String typeOfVehical) {
		this.typeOfVehical = typeOfVehical;
	}
    
    


}
