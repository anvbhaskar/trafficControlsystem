package com.example.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import com.example.dao.ISensorRepository;
import com.example.entity.Sensor;

@RestController
public class RestSignalController {
	
	@Autowired
    private ISensorRepository repo;
	
	static final Logger logger = LogManager.getLogger(RestSignalController.class.getName());
	
	// CREATE
    @RequestMapping("/sensor/")
    @ResponseBody
    public String createSensor(String speedOfVehical, String typeOfVehical) {
        Sensor sensor = new Sensor(speedOfVehical, typeOfVehical);
        try {
            repo.save(sensor);
        } catch (Exception e) {
            logger.error(e.getMessage());
            return e.getMessage();
        }
        return "creation successful: " + String.valueOf(sensor.getSignalId());
    }



}
