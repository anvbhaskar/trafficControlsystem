package com.example.demo;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class DemoApplicationTests {

	//@Test
	public void contextLoads() {
	}

}
