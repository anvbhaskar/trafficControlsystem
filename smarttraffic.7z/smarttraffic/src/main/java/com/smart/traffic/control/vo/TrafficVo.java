package com.smart.traffic.control.vo;

import java.io.Serializable;
import java.util.List;



public class TrafficVo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5016251641341422038L;
	
	private String userId;
	private String name;
	private String email;
	private String vehicleType;
	List<String> rootIdList;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	public List<String> getRootIdList() {
		return rootIdList;
	}
	public void setRootIdList(List<String> rootIdList) {
		this.rootIdList = rootIdList;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

}
