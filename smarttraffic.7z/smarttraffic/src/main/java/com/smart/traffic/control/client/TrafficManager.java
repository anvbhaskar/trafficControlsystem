package com.smart.traffic.control.client;

import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.smart.traffic.control.vo.TrafficVo;

public class TrafficManager {
	
	public static void main(String []args) {
		
		 final String uri = "http://localhost:8088/showtraffic?name=User";
	     
		    RestTemplate restTemplate = new RestTemplate();
		     
		    HttpHeaders headers = new HttpHeaders();
		    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		    HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		    
		    TrafficVo vo =  restTemplate.getForObject(uri, TrafficVo.class);
		     
		    System.out.println(vo.getName());
		    
		   // ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);
		     
		    //System.out.println(result);		
	}

}
