package com.smart.traffic.control.services;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smart.traffic.control.vo.Greeting;
import com.smart.traffic.control.vo.TrafficVo;

@RestController
public class TrafficControlService {

	
    @RequestMapping("/showtraffic")
    public TrafficVo greeting(@RequestParam(value="name", defaultValue="123") String name) {
        
    	TrafficVo trafficVo = new TrafficVo();
    	trafficVo.setUserId("123");
    	trafficVo.setName("ABC");
    	trafficVo.setEmail("abc@gmail.com");
    	trafficVo.setVehicleType("Car");
    	
    	List<String> rootIdList = new ArrayList<String>();
    	rootIdList.add("AA");
    	rootIdList.add("BB");
    	
    	trafficVo.setRootIdList(rootIdList);
    	
    	
    	
    	return trafficVo;
    }

	
}
