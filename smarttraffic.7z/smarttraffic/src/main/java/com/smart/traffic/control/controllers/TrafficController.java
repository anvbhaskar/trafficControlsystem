package com.smart.traffic.control.controllers;

import java.util.Arrays;

import javax.websocket.server.PathParam;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.smart.traffic.control.vo.TrafficVo;

@Controller
public class TrafficController {
	
	
	@RequestMapping(value="/showTrafficData/{userid}", method=RequestMethod.GET)
	public String showTrafficData(@PathVariable String userid,Model model) {  
	  
		
		
		final String uri = "http://localhost:8088/showtraffic?name=User";
	     
	    RestTemplate restTemplate = new RestTemplate();
	     
	    HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
	    
	    TrafficVo trafficVo =  restTemplate.getForObject(uri, TrafficVo.class);
	    model.addAttribute("trafficData", trafficVo);
	    
	   // ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);
	 
	    return "showTrafficeData";
	    
	// return new ModelAndView("showTrafficeData",model);  
	    
	}  

	@RequestMapping(value="/home")
	public String showTrafficData() {  
	  
	    return "welcome";
	    
	}
	
	
	

}
